javac -classpath /usr/local/hadoop/hadoop-core-0.20.203.0.jar -d fritem_classes/ Project.java

jar -cvf  fritem.jar -C fritem_classes/ .

hadoop fs -rmr output_fritem

hadoop jar fritem.jar Project  fritem_input output_fritem


#to see output
#hadoop fs -cat output_fritem/part-r-00000
