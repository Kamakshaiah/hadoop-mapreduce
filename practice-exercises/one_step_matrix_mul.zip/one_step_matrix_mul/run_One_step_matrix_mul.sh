javac -Xlint -classpath /home/hadoop/2.2.0/share/hadoop/common/hadoop-common-2.2.0.jar:/home/hadoop/2.2.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-2.2.0.jar:/home/hadoop/2.2.0/share/hadoop/common/lib/commons-cli-1.2.jar -d OneStepMatrixMultiplication_classes/ OneStepMatrixMultiplication.java


jar -cvf  OneStepMatrixMultiplication.jar -C OneStepMatrixMultiplication_classes/ .

hadoop fs -rmr output

hadoop jar OneStepMatrixMultiplication.jar OneStepMatrixMultiplication  input/ output

#to see output

#hadoop fs -cat output/part-r-00000
