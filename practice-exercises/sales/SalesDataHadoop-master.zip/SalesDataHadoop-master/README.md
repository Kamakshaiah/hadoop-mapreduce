# Sales Data Project for Hadoop
This project is based on the blog post I did ["Crafting a realworld Hadoop example for sales data"](http://dataissexy.wordpress.com/2013/10/20/crafting-a-realworld-hadoop-example-for-sales-data-part-1/) a series of posts developing some algorithms and then incorporating that into a Hadoop job.


